import AdminLogin from "../../../src/components/units/admin/login/AdminLogin.container";

export default function AdminLoginPage() {
   return <AdminLogin />;
}
