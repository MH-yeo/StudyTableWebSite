import styled from "@emotion/styled";
import HomeSectionCustomer from "../src/components/units/home/section/form/HomeSectionForm.container";
import HomeSectionInfo from "../src/components/units/home/section/info/HomeSectionInfo.container";

const Wrapper = styled.div``;

export default function Home() {
   return (
      <Wrapper>
         <HomeSectionInfo />
         <HomeSectionCustomer />
      </Wrapper>
   );
}
