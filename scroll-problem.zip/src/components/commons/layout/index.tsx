import styled from "@emotion/styled";
import { useRouter } from "next/router";
import LayoutBanner from "./banner/LayoutBanner.container";
import LayoutFooter from "./footer/LayoutFooter.container";
import LayoutNavigation from "./navigation/LayoutNavigation.container";
import { useEffect, useRef, useState } from "react";

const HIDDEN_BANNERS = ["/boards/new", "/routed/[number]/edit", "/admin/login"];
const HIDDEN_FOOTER = ["/admin/login"];
const HIDDEN_NAVIGATION = ["/admin/login"];

export const Background = styled.div`
   display: flex;
   flex-direction: column;
   background-color: #ffffff;
`;
export const Wrapper = styled.div`
   display: flex;
   flex-direction: row;
`;

export default function Layout(props) {
   const [navColor, setNavColor] = useState(true);
   const [formButton, setFormButton] = useState(true);
   const router = useRouter();
   const isHiddenBanner = HIDDEN_BANNERS.includes(router.pathname);
   const isHiddenFooter = HIDDEN_FOOTER.includes(router.pathname);
   const isHiddenNavigation = HIDDEN_NAVIGATION.includes(router.pathname);
   const bottomRef = useRef<HTMLInputElement>(null);

   const listenScrollEvent = () => {
      if (window.scrollY < 1030) {
         return setNavColor(true);
      } else if (window.scrollY > 1030) {
         return setNavColor(false);
      }
   };

   useEffect(() => {
      window.addEventListener("scroll", listenScrollEvent);

      return () => window.removeEventListener("scroll", listenScrollEvent);
   }, []);

   useEffect(() => {
      return () => bottomRef.current?.scrollIntoView();
   }, [formButton]);

   const onClickFormButton = () => {
      setFormButton((prev) => !prev);
      console.log(formButton);
   };
   return (
      <>
         {!isHiddenNavigation && (
            <LayoutNavigation
               navColor={navColor}
               onClickFormButton={onClickFormButton}
            />
         )}
         {!isHiddenBanner && <LayoutBanner />}
         <Background>{props.children}</Background>
         {!isHiddenFooter && <LayoutFooter ref={bottomRef} />}
      </>
   );
}
