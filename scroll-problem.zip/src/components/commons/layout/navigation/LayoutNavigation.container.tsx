import { useRouter } from "next/router";
import LayoutNavigationUI from "./LayoutNavigation.presenter";

export default function LayoutNavigation(props) {
   const router = useRouter();
   const onClickToHome = () => {
      router.push("/");
   };

   const onClickToAdminLogin = () => {
      router.push("/admin/login");
   };

   return (
      <LayoutNavigationUI
         onClickToHome={onClickToHome}
         onClickToAdminLogin={onClickToAdminLogin}
         onClickFormButton={props.onClickFormButton}
         navColor={props.navColor}
      />
   );
}
