import { Modal } from "antd";
import styled from "@emotion/styled";

export const MyModal = styled(Modal)``;
