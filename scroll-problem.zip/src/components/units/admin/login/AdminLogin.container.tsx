import { useRouter } from "next/router";
import AdminLoginUI from "./AdminLogin.presenter";

export default function AdminLogin() {
   const router = useRouter();
   const onClickToHome = () => {
      router.push("/");
   };

   return <AdminLoginUI onClickToHome={onClickToHome} />;
}
