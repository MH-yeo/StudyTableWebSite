import BoardListUI from "./BoardList.presenter";
import { useRouter } from "next/router";
import { useQuery } from "@apollo/client";
import { FETCH_BOARDS, FETCH_BOARDS_COUNT } from "./BoardList.queries";

export default function BoardList() {
   const router = useRouter();
   const { data, refetch } = useQuery(FETCH_BOARDS);
   const { data: boardCounts } = useQuery(FETCH_BOARDS_COUNT);

   const onClickToDetail = (event: any) => {
      router.push(`/routed/${event.target.id}`);
   };

   const onClickWrite = () => {
      router.push(`/boards/new`);
   };

   return (
      <BoardListUI
         data={data}
         onClickToDetail={onClickToDetail}
         onClickWrite={onClickWrite}
         boardCounts={boardCounts}
         refetch={refetch}
      />
   );
}
