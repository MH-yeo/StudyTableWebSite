import Pagination01 from "../../../commons/pagination/01/Pagination01.container";
import BoardSideBar from "../sidebar/BoardSideBar";
import * as S from "./BoardList.styles";
import { IBoardListUI } from "./BoardList.types";

export default function BoardListUI(props: IBoardListUI) {
   return (
      <S.Background>
         <BoardSideBar />
         <S.Wrapper>
            <S.TableWrapper>
               <S.TableRowHead>
                  <S.TableHeadCentered>번호</S.TableHeadCentered>
                  <S.TableHeadTitle>제목</S.TableHeadTitle>
                  <S.TableHeadCentered>이름</S.TableHeadCentered>
                  <S.TableHeadCentered>추천</S.TableHeadCentered>
                  <S.TableHeadCentered>날짜</S.TableHeadCentered>
               </S.TableRowHead>
               <S.GrayLine></S.GrayLine>
               <S.TableBody>
                  {props.data?.fetchBoards.map((el: any) => (
                     <S.TableRow key={el._id}>
                        <S.TableDataCentered key={el._id}>
                           {parseInt(el._id.slice(-4), 16)}
                        </S.TableDataCentered>
                        <S.TableDataTitle
                           onClick={props.onClickToDetail}
                           key={el._id}
                           id={el._id}
                        >
                           {el.title}
                        </S.TableDataTitle>
                        <S.TableDataCentered key={el._id}>
                           {el.writer}
                        </S.TableDataCentered>
                        <S.TableDataCentered key={el._id}>
                           {el.likeCount - el.dislikeCount}
                        </S.TableDataCentered>
                        <S.TableDataCentered key={el._id}>
                           {el.createdAt.split("T")[0].replaceAll("-", ".")}
                        </S.TableDataCentered>
                     </S.TableRow>
                  ))}
               </S.TableBody>
            </S.TableWrapper>
            <S.Pagina>
               <Pagination01
                  boardCounts={props.boardCounts}
                  refetch={props.refetch}
               />
            </S.Pagina>
            <S.Footer>
               <S.SearchWrite>
                  <S.Serach></S.Serach>
                  <S.Write type="primary" onClick={props.onClickWrite}>
                     <img src="/board/detail/write.png"></img> 글쓰기
                  </S.Write>
               </S.SearchWrite>
            </S.Footer>
         </S.Wrapper>
      </S.Background>
   );
}
