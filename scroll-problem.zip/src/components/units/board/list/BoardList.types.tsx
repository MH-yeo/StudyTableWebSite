export interface IBoardListUI {
   onClickToDetail: (event: any) => void;
   onClickWrite: () => void;
   data?: any;
}
