import styled from "@emotion/styled";
import { useRouter } from "next/router";

const Wrapper = styled.div`
   display: flex;
   flex-direction: column;
   padding: 16px;
`;
const MainTitle = styled.div`
   font-size: 18px;
   color: #333;
   font-weight: bold;
`;
const SubTitle = styled.a`
   font-size: 16px;
   padding-left: 10px;
   cursor: pointer;
`;
const GrayLine = styled.div`
   width: 100%;
   margin: 8px 0px;
   padding: 0px 12px;
   border: 1px solid #eff0ed;
`;

export default function BoardSideBar() {
   const router = useRouter();
   const LayoutSideBar = styled.div`
      width: 175px;
      height: 100%;
      box-shadow: 1px 2px 3px #c4c4c4;
      background-color: white;
      border-radius: 10px;
   `;
   function onClickToBoards() {
      router.push("/boards/list");
   }

   return (
      <LayoutSideBar>
         <Wrapper>
            <MainTitle>커뮤니티</MainTitle>
            <SubTitle onClick={onClickToBoards}>자유게시판</SubTitle>
            <SubTitle>주식/투자</SubTitle>
            <SubTitle>정치</SubTitle>
            <SubTitle>이슈</SubTitle>
            <GrayLine />
            <MainTitle>생활</MainTitle>
            <SubTitle>중고장터</SubTitle>
            <SubTitle>제휴부동산</SubTitle>
         </Wrapper>
      </LayoutSideBar>
   );
}
