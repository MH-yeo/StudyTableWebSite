import { useState } from "react";
import { Modal } from "antd";
import { useRouter } from "next/router";
import HomeSectionFormUI from "./HomeSectionForm.presenter";

import {
   collection,
   getFirestore,
   addDoc,
   getDocs,
} from "firebase/firestore/lite";
import { firebaseApp } from "../../../../../../pages/_app";

export default function HomeSectionForm() {
   const [storeName, setStoreName] = useState("");
   const [phoneNum, setPhoneNum] = useState("");
   const [address, setAddress] = useState("");
   const [seats, setSeats] = useState("");
   const [checkBox, setCheckBox] = useState(false);
   const [isDisabled, setIsDisabled] = useState(true);
   const router = useRouter();

   const onChangeStoreName = (e) => {
      setStoreName(e.target.value);
      if (e.target.value && phoneNum && address && seats && checkBox)
         setIsDisabled(false);
      else setIsDisabled(true);
   };
   const onChangePhoneNum = (e) => {
      setPhoneNum(e.target.value);
      if (storeName && e.target.value && address && seats && checkBox)
         setIsDisabled(false);
      else setIsDisabled(true);
   };
   const onChangeAddress = (e) => {
      setAddress(e.target.value);
      if (storeName && phoneNum && e.target.value && seats && checkBox)
         setIsDisabled(false);
      else setIsDisabled(true);
   };
   const onChangeSeats = (e) => {
      setSeats(e.target.value);
      if (storeName && phoneNum && address && e.target.value && checkBox)
         setIsDisabled(false);
      else setIsDisabled(true);
   };
   const onChangeCheckBox = (e) => {
      console.log(e.target.checked);
      setCheckBox((prev) => !prev);
      if (storeName && phoneNum && address && seats && e.target.checked)
         setIsDisabled(false);
      else setIsDisabled(true);
   };
   const onClickToSubmit = async () => {
      try {
         const board = collection(getFirestore(firebaseApp), "Form");
         await addDoc(board, {
            storeName,
            phoneNum,
            address,
            seats,
         });
         modalSuccess("상담요청이 완료되었습니다.");
         setStoreName("");
         setPhoneNum("");
         setAddress("");
         setSeats("");
         setCheckBox(false);
         setIsDisabled(true);
      } catch (error: any) {
         modalError(`${error.message}`);
      }
   };
   const modalSuccess = (text) => {
      Modal.success({
         title: text,
      });
   };
   const modalError = (text) => {
      Modal.error({
         title: text,
      });
   };

   const phoneNumHypen = (value) => {
      if (!value) {
         return "";
      }

      value = value.replace(/[^0-9]/g, "");

      const result = [];
      let restNumber = "";

      // 지역번호와 나머지 번호로 나누기
      if (value.startsWith("02")) {
         // 서울 02 지역번호
         result.push(value.substr(0, 2));
         restNumber = value.substring(2);
      } else if (value.startsWith("1")) {
         // 지역 번호가 없는 경우
         // 1xxx-yyyy
         restNumber = value;
      } else {
         // 나머지 3자리 지역번호
         // 0xx-yyyy-zzzz
         result.push(value.substr(0, 3));
         restNumber = value.substring(3);
      }

      if (restNumber.length === 7) {
         // 7자리만 남았을 때는 xxx-yyyy
         result.push(restNumber.substring(0, 3));
         result.push(restNumber.substring(3));
      } else {
         result.push(restNumber.substring(0, 4));
         result.push(restNumber.substring(4));
      }

      return result.filter((val) => val).join("-");
   };
   const onClickToPrivacyPolicy = () => {
      router.push("/info/privacy.policy.html");
   };

   return (
      <>
         <HomeSectionFormUI
            onChangeStoreName={onChangeStoreName}
            onChangePhoneNum={onChangePhoneNum}
            onChangeAddress={onChangeAddress}
            onChangeSeats={onChangeSeats}
            onClickToSubmit={onClickToSubmit}
            onChangeCheckBox={onChangeCheckBox}
            storeName={storeName}
            phoneNum={phoneNum}
            address={address}
            seats={seats}
            checkBox={checkBox}
            isDisabled={isDisabled}
            phoneNumHypen={phoneNumHypen}
            onClickToPrivacyPolicy={onClickToPrivacyPolicy}
         />
      </>
   );
}
