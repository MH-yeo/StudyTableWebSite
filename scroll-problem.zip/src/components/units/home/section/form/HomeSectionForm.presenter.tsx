import { RightOutlined } from "@ant-design/icons";
import * as S from "./HomeSectionForm.styles";

export default function HomeSectionFormUI(props) {
   return (
      <>
         <S.Section>
            <S.TextWrapper>
               <S.MainP>
                  지금 바로
                  <br />
                  상담 받아보세요
               </S.MainP>
               <S.Context>
                  부담없이 무료 상담을 받아보세요. <br />
                  전문 컨설턴트가 내 매장 맞춤 상담을 도와드립니다.
                  <br />
               </S.Context>
            </S.TextWrapper>
            <S.InputGroup>
               <S.InputWrapper>
                  <S.InputBox
                     onChange={props.onChangeStoreName}
                     value={props.storeName}
                  />
                  <S.Label>매장 이름 (필수)</S.Label>
               </S.InputWrapper>
               <S.InputWrapper>
                  <S.InputBox
                     onChange={props.onChangePhoneNum}
                     value={props.phoneNumHypen(props.phoneNum)}
                     maxLength={13}
                  />
                  <S.Label>휴대전화 번호 (필수)</S.Label>
               </S.InputWrapper>
               <S.InputWrapper>
                  <S.InputBox
                     onChange={props.onChangeAddress}
                     value={props.address}
                  />
                  <S.Label>
                     지역 (필수)<S.MySpan>ex. 서울시 역삼동</S.MySpan>
                  </S.Label>
               </S.InputWrapper>
               <S.InputWrapper>
                  <S.InputBox
                     onChange={props.onChangeSeats}
                     value={props.seats}
                  />
                  <S.Label>
                     예상 관리 좌석 (필수)<S.MySpan>ex. 5 좌석</S.MySpan>
                  </S.Label>
               </S.InputWrapper>
               <S.PolicyWrapper>
                  <S.PolicyLabel htmlFor="policy">
                     <S.PolicyInput
                        type="checkbox"
                        id="policy"
                        name="policy"
                        onChange={props.onChangeCheckBox}
                        checked={props.checkBox}
                     />
                     <S.PolicySpan>개인정보 수집 이용 동의</S.PolicySpan>
                  </S.PolicyLabel>
                  <div>
                     <RightOutlined
                        onClick={props.onClickToPrivacyPolicy}
                        style={{ cursor: "pointer" }}
                     />
                  </div>
               </S.PolicyWrapper>
               <S.SubmitButton
                  type="primary"
                  onClick={props.onClickToSubmit}
                  disabled={props.isDisabled}
               >
                  상담요청
               </S.SubmitButton>
            </S.InputGroup>
         </S.Section>
      </>
   );
}
